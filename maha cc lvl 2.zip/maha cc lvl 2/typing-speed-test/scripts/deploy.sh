#!/bin/bash
set -e

echo "Deploying application using Terraform..."
cd "$(dirname "$0")/../terraform"
terraform init
terraform apply -auto-approve

echo "Deployment complete!"
echo "To scale the deployment, run: terraform apply -var=\"replicas=3\""
