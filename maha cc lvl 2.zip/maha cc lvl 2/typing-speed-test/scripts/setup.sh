#!/bin/bash
set -e

echo "Running Ansible playbook to setup environment..."
cd "$(dirname "$0")/.."
ansible-playbook -i ansible/inventory.ini ansible/playbook.yml

echo "Environment setup complete!"
