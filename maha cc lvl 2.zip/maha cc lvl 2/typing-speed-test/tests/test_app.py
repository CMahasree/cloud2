import pytest
import sys
import os

# Add app directory to path to import app
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../app')))

from app import app

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_health_endpoint(client):
    """Test the health endpoint returns healthy status"""
    rv = client.get('/health')
    assert rv.status_code == 200
    assert rv.get_json() == {"status": "healthy"}

def test_home_page(client):
    """Test the home page loads successfully"""
    rv = client.get('/')
    assert rv.status_code == 200
    assert b"Typing Speed Test" in rv.data
