terraform {
  required_providers {
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.23.0"
    }
  }
}

provider "kubernetes" {
  config_path    = "~/.kube/config"
  config_context = "kind-typing-cluster"
}

# Namespace
resource "kubernetes_namespace" "app_namespace" {
  metadata {
    name = var.namespace
  }
}

# ConfigMap
resource "kubernetes_config_map" "app_config" {
  metadata {
    name      = "typing-app-config"
    namespace = kubernetes_namespace.app_namespace.metadata[0].name
  }

  data = {
    PORT = "5000"
  }
}

# Deployment
resource "kubernetes_deployment" "app_deployment" {
  metadata {
    name      = "typing-app"
    namespace = kubernetes_namespace.app_namespace.metadata[0].name
    labels = {
      app = "typing-app"
    }
  }

  spec {
    replicas = var.replicas

    selector {
      match_labels = {
        app = "typing-app"
      }
    }

    template {
      metadata {
        labels = {
          app = "typing-app"
        }
      }

      spec {
        container {
          image             = "typing-speed-test:latest"
          name              = "typing-app"
          image_pull_policy = "IfNotPresent"

          port {
            container_port = 5000
          }

          env_from {
            config_map_ref {
              name = kubernetes_config_map.app_config.metadata[0].name
            }
          }

          resources {
            limits = {
              cpu    = "250m"
              memory = "256Mi"
            }
            requests = {
              cpu    = "100m"
              memory = "128Mi"
            }
          }

          liveness_probe {
            http_get {
              path = "/health"
              port = 5000
            }
            initial_delay_seconds = 15
            period_seconds        = 20
          }

          readiness_probe {
            http_get {
              path = "/health"
              port = 5000
            }
            initial_delay_seconds = 5
            period_seconds        = 10
          }
        }
      }
    }
  }
}

# Service
resource "kubernetes_service" "app_service" {
  metadata {
    name      = "typing-app-service"
    namespace = kubernetes_namespace.app_namespace.metadata[0].name
  }
  spec {
    selector = {
      app = kubernetes_deployment.app_deployment.spec[0].template[0].metadata[0].labels.app
    }
    port {
      port        = 5000
      target_port = 5000
      node_port   = 30005
    }
    type = "NodePort"
  }
}
