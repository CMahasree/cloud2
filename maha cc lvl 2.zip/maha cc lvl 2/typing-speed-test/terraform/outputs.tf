output "namespace" {
  description = "Kubernetes namespace"
  value       = kubernetes_namespace.app_namespace.metadata[0].name
}

output "service_name" {
  description = "Kubernetes service name"
  value       = kubernetes_service.app_service.metadata[0].name
}

output "replica_count" {
  description = "Number of replicas"
  value       = kubernetes_deployment.app_deployment.spec[0].replicas
}
