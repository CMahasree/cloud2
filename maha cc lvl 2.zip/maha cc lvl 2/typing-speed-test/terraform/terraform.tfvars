namespace = "typing-speed-test"
replicas  = 2
