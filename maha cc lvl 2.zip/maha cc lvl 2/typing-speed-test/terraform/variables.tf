variable "namespace" {
  description = "The namespace to deploy the application into"
  type        = string
  default     = "typing-speed-test"
}

variable "replicas" {
  description = "Number of pod replicas"
  type        = number
  default     = 2
}
