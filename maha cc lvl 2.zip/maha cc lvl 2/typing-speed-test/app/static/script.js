const RANDOM_QUOTE_API_URL = 'https://api.quotable.io/random';
const quoteDisplayElement = document.getElementById('quote-display');
const quoteInputElement = document.getElementById('quote-input');
const timerElement = document.getElementById('time');
const wpmElement = document.getElementById('wpm');
const accuracyElement = document.getElementById('accuracy');
const correctCharsElement = document.getElementById('correct-chars');
const incorrectCharsElement = document.getElementById('incorrect-chars');
const restartBtn = document.getElementById('restart-btn');

let startTime;
let timerInterval;
let totalTypedChars = 0;
let correctChars = 0;
let incorrectChars = 0;
let timeElapsed = 0;
let typingStarted = false;

// Fallback quotes in case API fails
const fallbackQuotes = [
    "The quick brown fox jumps over the lazy dog. This is a classic typing test sentence.",
    "Programming isn't about what you know; it's about what you can figure out.",
    "The only way to do great work is to love what you do. If you haven't found it yet, keep looking.",
    "Technology is best when it brings people together. DevOps makes shipping code faster and safer."
];

async function getRandomQuote() {
    try {
        const response = await fetch(RANDOM_QUOTE_API_URL);
        if (!response.ok) throw new Error('API down');
        const data = await response.json();
        return data.content;
    } catch (error) {
        // Fallback if quotable API is down
        return fallbackQuotes[Math.floor(Math.random() * fallbackQuotes.length)];
    }
}

async function renderNewQuote() {
    const quote = await getRandomQuote();
    quoteDisplayElement.innerHTML = '';
    
    // Create span for each character for color coding
    quote.split('').forEach(character => {
        const characterSpan = document.createElement('span');
        characterSpan.innerText = character;
        quoteDisplayElement.appendChild(characterSpan);
    });
    
    quoteInputElement.value = null;
    resetStats();
}

function resetStats() {
    typingStarted = false;
    clearInterval(timerInterval);
    timerElement.innerText = '0s';
    wpmElement.innerText = '0';
    accuracyElement.innerText = '100%';
    correctCharsElement.innerText = '0';
    incorrectCharsElement.innerText = '0';
    totalTypedChars = 0;
    correctChars = 0;
    incorrectChars = 0;
    timeElapsed = 0;
    quoteInputElement.disabled = false;
    quoteInputElement.focus();
}

function startTimer() {
    startTime = new Date();
    typingStarted = true;
    timerInterval = setInterval(() => {
        timeElapsed = Math.floor((new Date() - startTime) / 1000);
        timerElement.innerText = timeElapsed + 's';
        updateStats();
    }, 1000);
}

function updateStats() {
    if (timeElapsed > 0) {
        // WPM calculation (standard: 5 chars = 1 word)
        const wpm = Math.round((correctChars / 5) / (timeElapsed / 60));
        wpmElement.innerText = wpm > 0 ? wpm : 0;
    }

    if (totalTypedChars > 0) {
        const accuracy = Math.round((correctChars / totalTypedChars) * 100);
        accuracyElement.innerText = accuracy + '%';
    }
}

quoteInputElement.addEventListener('input', () => {
    if (!typingStarted && quoteInputElement.value.length > 0) {
        startTimer();
    }

    const arrayQuote = quoteDisplayElement.querySelectorAll('span');
    const arrayValue = quoteInputElement.value.split('');
    
    let currentCorrect = 0;
    let currentIncorrect = 0;
    let isComplete = true;

    arrayQuote.forEach((characterSpan, index) => {
        const character = arrayValue[index];
        
        if (character == null) {
            characterSpan.classList.remove('correct');
            characterSpan.classList.remove('incorrect');
            isComplete = false;
        } else if (character === characterSpan.innerText) {
            characterSpan.classList.add('correct');
            characterSpan.classList.remove('incorrect');
            currentCorrect++;
        } else {
            characterSpan.classList.remove('correct');
            characterSpan.classList.add('incorrect');
            currentIncorrect++;
            isComplete = false;
        }
    });

    correctChars = currentCorrect;
    incorrectChars = currentIncorrect;
    totalTypedChars = arrayValue.length;

    correctCharsElement.innerText = correctChars;
    incorrectCharsElement.innerText = incorrectChars;

    updateStats();

    // Check if finished
    if (isComplete) {
        clearInterval(timerInterval);
        quoteInputElement.disabled = true;
    }
});

restartBtn.addEventListener('click', renderNewQuote);

// Init
renderNewQuote();
